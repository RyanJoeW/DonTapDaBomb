package com.ryan.dontapdabomb.dontapdabomb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonTapDaBombApplicationTests {

    @Test
    void contextLoads() {
    }

}
