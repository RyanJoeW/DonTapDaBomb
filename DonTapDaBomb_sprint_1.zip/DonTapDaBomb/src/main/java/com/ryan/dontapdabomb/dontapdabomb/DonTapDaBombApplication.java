package com.ryan.dontapdabomb.dontapdabomb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonTapDaBombApplication {

    public static void main(String[] args) {
        SpringApplication.run(DonTapDaBombApplication.class, args);
    }

}
